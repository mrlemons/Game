package game.main;

import game.controller.GameController;

public class MainClass
{

	public static void main(String[] args)
	{
		GameController gameControl = new GameController();
		//testing
		

	}

}
